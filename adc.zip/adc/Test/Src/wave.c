#include "wave.h"
#include "main.h"
#include "bit_operation.h"

#define ADC2VOL(ADCValue) ((float)(ADCValue) * 3.3 / 4096)
#define VOL2ADC(volt) ((volt) / 3.3 * 4096)
#define SAMPLE_POINTS 256

static float v_scale_list[] = {0.1, 0.2, 0.5, 0.8, 1, 1.2, 1.5, 1.8, 2};
static uint8_t v_scale_index;
Y_Axis volt_on_y_axis;

static void get_max_min_pp_value(uint16_t *ADCValue, uint16_t *a_max_value, uint16_t *a_min_value, uint16_t *a_pp_value);
static void get_dc_value(uint16_t *ADCValue, uint16_t *a_dc_value);
static void voltage_range_auto_select(float amp_voltage);

//计算峰峰值
static void get_max_min_pp_value(uint16_t *ADCValue, uint16_t *a_max_value, uint16_t *a_min_value, uint16_t *a_pp_value)
{
	uint16_t i;
	uint16_t a_temp_max_value = ADCValue[0], a_temp_min_value = ADCValue[0];

	for (i = 1; i < SAMPLE_POINTS; i++)
	{
		if (ADCValue[i] > a_temp_max_value)
			a_temp_max_value = ADCValue[i];
		if (ADCValue[i] < a_temp_min_value)
			a_temp_min_value = ADCValue[i];
	}

	if (a_max_value != NULL)
		*a_max_value = a_temp_max_value;
	if (a_min_value != NULL)
		*a_min_value = a_temp_min_value;
	if (a_pp_value != NULL)
		*a_pp_value = a_temp_max_value - a_temp_min_value;
}

//计算中心电压
static void get_dc_value(uint16_t *ADCValue, uint16_t *a_dc_value)
{
	uint16_t i;
	uint32_t a_sum = 0;
	for (i = 0; i < SAMPLE_POINTS; i++)
		a_sum += ADCValue[i];
	*a_dc_value = a_sum / SAMPLE_POINTS;
}

float get_pp_voltage(uint16_t *ADCValue)
{
	uint16_t a_pp_value;
	get_max_min_pp_value(ADCValue, NULL, NULL, &a_pp_value);
	return ADC2VOL(a_pp_value);
}

float get_dc_voltage(uint16_t *ADCValue)
{
	uint16_t a_dc_value;
	get_dc_value(ADCValue, &a_dc_value);
	return ADC2VOL(a_dc_value);
}

void auto_scale(uint16_t *ADCValue)
{
	uint16_t a_max_value, a_min_value, a_pp_value;
	float exact_voltage, floor_voltage, ceil_voltage;
	get_max_min_pp_value(ADCValue, &a_max_value, &a_min_value, &a_pp_value);
	voltage_range_auto_select(ADC2VOL(a_pp_value/2));

	exact_voltage = ADC2VOL(a_max_value + a_min_value) / 2;
	floor_voltage = (uint8_t)(ADC2VOL((a_max_value + a_min_value)*5)) / 10.0;  //keep one decimal
	ceil_voltage = floor_voltage + 0.1;

	volt_on_y_axis.center_voltage = ceil_voltage - exact_voltage < exact_voltage - floor_voltage ? ceil_voltage : floor_voltage;
	volt_on_y_axis.max_voltage = volt_on_y_axis.center_voltage + v_scale_list[v_scale_index];
	volt_on_y_axis.min_voltage = volt_on_y_axis.center_voltage - v_scale_list[v_scale_index];
}

static void voltage_range_auto_select(float v_amplitude)
{
	uint8_t i = 0;
	for (i = 0; i < sizeof(v_scale_list) / sizeof(float); i++)
		if (v_amplitude < v_scale_list[i])
		{
			v_scale_index = i+1;
			break;
		}
}

//增加y轴坐标
void manual_inc_scale(void)
{
	if (v_scale_index + 1 < sizeof(v_scale_list) / sizeof(float))
		v_scale_index++;
	volt_on_y_axis.max_voltage = volt_on_y_axis.center_voltage + v_scale_list[v_scale_index];
	volt_on_y_axis.min_voltage = volt_on_y_axis.center_voltage - v_scale_list[v_scale_index];
}

//减小y轴坐标
void manual_dec_scale(void)
{
	if (v_scale_index - 1 >= 0)
		v_scale_index--;
	volt_on_y_axis.max_voltage = volt_on_y_axis.center_voltage + v_scale_list[v_scale_index];
	volt_on_y_axis.min_voltage = volt_on_y_axis.center_voltage - v_scale_list[v_scale_index];
}

void manual_inc_offset(void)
{
	if (volt_on_y_axis.center_voltage < 3.3)
	{
		volt_on_y_axis.center_voltage += 0.1;
		volt_on_y_axis.max_voltage += 0.1;
		volt_on_y_axis.min_voltage += 0.1;
	}
}

void manual_dec_offset(void)
{
	if (volt_on_y_axis.center_voltage > 0)
	{
		volt_on_y_axis.center_voltage -= 0.1;
		if (volt_on_y_axis.center_voltage < 0)
			volt_on_y_axis.center_voltage = 0;  // Avoid displaying -0.0
		volt_on_y_axis.max_voltage -= 0.1;
		volt_on_y_axis.min_voltage -= 0.1;
	}
}

void generate_wave(uint16_t *ADCValue, uint8_t *y)
{
	int16_t a_max_value = VOL2ADC(volt_on_y_axis.max_voltage);
	int16_t a_min_value = VOL2ADC(volt_on_y_axis.min_voltage);
	uint8_t i;

	for (i = 0; i < GRAPH_WIDTH - 1; i++)
	{
		if (ADCValue[i] <= a_max_value && ADCValue[i] >= a_min_value)
			y[i] = (GRAPH_HEIGHT - 1) * (a_max_value - ADCValue[i]) / (a_max_value - a_min_value) + GRAPH_START_Y;
		else if (ADCValue[i] > a_max_value)
			y[i] = GRAPH_START_Y;
		else if (ADCValue[i] < a_min_value)
			y[i] = GRAPH_HEIGHT + GRAPH_START_Y - 1;
	}
}

//波形触发
uint16_t trigger(uint16_t *ADCValue, uint16_t total_points)
{
	uint16_t i;
	uint16_t trigger_value = VOL2ADC(1.68);

	if (!is_trigger_on())
		return 0;

	for (i = 1; i < total_points - GRAPH_WIDTH + 2; i++)
	{
		if (get_trigger_edge())  // falling edge
		{
			if (ADCValue[i-1] > trigger_value && ADCValue[i] <= trigger_value)
			{
				trigger_success();
				if (is_trigger_single())
					pause();
				return i;
			}
		}
		else
		{
			if (ADCValue[i-1] <= trigger_value && ADCValue[i] > trigger_value)
			{
				trigger_success();
				if (is_trigger_single())
					pause();
				return i;
			}
		}
	}

	trigger_fail();
	return 0;
}
