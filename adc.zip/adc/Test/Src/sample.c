#include "tim.h"
#include "main.h"
#include "adc.h"
#include "bit_operation.h"

#define NUM_OF_SAMPLE_RATES 10
#define SAMPLE_POINTS 256

// 列出采样率
static uint32_t sample_rate_list[NUM_OF_SAMPLE_RATES] = {1000, 2500, 5000, 10000, 25000, 50000, 100000, 250000, 500000, 1000000};

// 索引
static int8_t sample_rate_index = 3;

//获得采样率
uint32_t get_sample_rate(void)
{
	return sample_rate_list[sample_rate_index];
}

//提高采样率
void inc_sample_rate(void)
{
	if (sample_rate_index < NUM_OF_SAMPLE_RATES - 1)
		sample_rate_index++;
	else
		sample_rate_index =  NUM_OF_SAMPLE_RATES - 1;
}

//降低采样率
void dec_sample_rate(void)
{
	if (sample_rate_index > 0 && sample_rate_index < NUM_OF_SAMPLE_RATES)
		sample_rate_index--;
	else
		sample_rate_index = 0;
}

//设置采样率
void set_sample_rate(uint32_t sample_rate)
{
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 32000000 / sample_rate);
	__HAL_TIM_SET_AUTORELOAD(&htim1, 64000000 / sample_rate - 1);
	TIM1->EGR = TIM_EGR_UG;
}

//重置采样率
void start_sample(uint16_t *ADCValue)
{
	HAL_Delay(1);
	HAL_ADCEx_Calibration_Start(&hadc1);
	HAL_ADC_Start_DMA(&hadc1, (uint32_t *)ADCValue, SAMPLE_POINTS);
}

//改变ADC引脚
void change_ADC_channel(void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
	if (is_mic_input())  // 麦克风
		sConfig.Channel = ADC_CHANNEL_4;
	else  //  Ain引脚
		sConfig.Channel = ADC_CHANNEL_0;
	sConfig.Rank = ADC_REGULAR_RANK_1;
	sConfig.SamplingTime = ADC_SAMPLINGTIME_COMMON_1;
	if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	{
		Error_Handler();
	}
}
