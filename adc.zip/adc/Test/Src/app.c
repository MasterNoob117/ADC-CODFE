#include "wave.h"
#include "spectrum.h"
#include "display.h"
#include "main.h"
#include "bit_operation.h"
#include "button.h"
#include "oled.h"
#include "source.h"

#define SAMPLE_POINTS 256

//按键操作
void button_operations(uint8_t button_state)
{
	switch (button_state)
	{
	case L_BUTTON_PRESSED:
	  if (is_displaying_scope_menu())
		  switch_wave_spectrum();
	  else if (is_displaying_output_menu())  // 输出菜单
		  increase_output_freq();
	  else if (is_displaying_trigger_menu())  // 触发器菜单
		  toggle_trigger();
	  else if (!is_paused())  //不在菜单中也不按
		  inc_sample_rate();
	  break;

	case R_BUTTON_PRESSED:
	  if (is_displaying_scope_menu())
		  toggle_scale();
	  else if (is_displaying_output_menu())
		  decrease_output_freq();
	  else if (is_displaying_trigger_menu())
		  switch_trigger_mode();
	  else if (!is_paused())
		  dec_sample_rate();
	  break;

	case U_BUTTON_PRESSED:
	  if (is_displaying_scope_menu())
		  next_information();
	  else if (is_displaying_output_menu())
		  increase_output_amplitude();
	  else if (is_displaying_trigger_menu())
		  switch_trigger_edge();
	  else if (is_adjust_y_axis_scale())  // 调整y轴
		  manual_inc_scale();
	  else if (is_adjust_y_axis_offset())
		  manual_inc_offset();
	  break;

	case D_BUTTON_PRESSED:
	  if (is_displaying_scope_menu())
	  {
		  switch_channel();
		  change_ADC_channel();
	  }
	  else if (is_displaying_output_menu())
		  decrease_output_amplitude();
	  else if (is_adjust_y_axis_scale())
		  manual_dec_scale();
	  else if (is_adjust_y_axis_offset())
		  manual_dec_offset();
	  break;

	case UD_BUTTON_HOLD:
	  if (is_manual_scale())  //显示波形
		  toggle_scale_offset();
	  break;

	case OK_BUTTON_PRESSED:
	  if (is_displaying_output_menu())
		  change_output_waveform();
	  else
		  toggle_pause();
	  break;

	case OK_BUTTON_HOLD:
	  if (is_displaying_output_menu())
	  {
		  if (is_output_on())
			  stop_output();
		  else
			  start_output();

		  toggle_output();
	  }
	  else if (!is_displaying_trigger_menu())
		  toggle_scope_menu();  //开关菜单
	  break;

	case L_BUTTON_HOLD:
	  if (!is_displaying_scope_menu() && !is_displaying_trigger_menu())
		  toggle_output_menu();  //开关菜单
	  break;
	case R_BUTTON_HOLD:
	  if (!is_displaying_scope_menu() && !is_displaying_output_menu() && is_displaying_wave())
		  toggle_trigger_menu();  //开关菜单
	  break;
	default:
	  break;
	}
}


//得到波形
void get_wave(uint16_t *ADCValue, uint8_t *wave)
{
	uint16_t trigger_index;
	if (is_auto_scale())
		auto_scale(ADCValue);

	trigger_index = trigger(ADCValue, SAMPLE_POINTS);
	generate_wave(ADCValue + trigger_index, wave);
}

//显示信息
void wave_view(uint16_t *ADCValue, uint16_t *FFTValue, uint32_t sample_rate, uint8_t *wave)
{
	OLED_Clear();
	display_coordinate();
	display_status();
	display_wave(wave);
	display_y_axis();
	display_channel();

	if (is_trigger_on())
		display_trigger_edge();

	if (is_displaying_time_div())  // 时间分度
		display_time_div(sample_rate);
	else if (is_displaying_Vpp())  // 峰峰值
		display_Vpp(get_pp_voltage(ADCValue));
	else if (is_displaying_Vdc())  // 中心电压
		display_Vdc(get_dc_voltage(ADCValue));
	else if (is_displaying_freq()) // 频率
		display_frequency(get_frequency(FFTValue, sample_rate));

	if (is_displaying_scope_menu())
		display_scope_menu();
	else if (is_displaying_output_menu())
		display_output_menu(get_output_information());
	else if (is_displaying_trigger_menu())
		display_trigger_menu();

	OLED_Refresh();
}

//得到频谱
void get_spectrum(uint16_t *FFTValue, uint8_t *spectrum)
{
	generate_spectrum(FFTValue, spectrum);
}

//显示频谱信息
void spectrum_view(uint8_t *spectrum, uint32_t sample_rate)
{
	OLED_Clear();
	display_spectrum(spectrum);
	display_freq_div(sample_rate);
	display_channel();
	if (is_displaying_scope_menu())
		display_scope_menu();
	else if (is_displaying_output_menu())
		display_output_menu(get_output_information());
	OLED_Refresh();
}

//复制数组
void copy_array(uint16_t *array1, uint16_t *array2, uint16_t length)
{
	uint16_t i;
	for (i = 0; i < length; i++)
		*array2++ = *array1++;
}
