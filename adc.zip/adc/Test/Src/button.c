#include "button.h"
#include "main.h"
//按键读取
void read_button(uint8_t *button_state)
{
	uint8_t i;
	if (*button_state != NO_BUTTON_PRESSED && encode_button())
	{
		*button_state = 0xFF;
		return ;
	}

	*button_state = encode_button();
	if (*button_state == NO_BUTTON_PRESSED)
		return ;

	HAL_Delay(50);
	*button_state = encode_button();
	if (*button_state == NO_BUTTON_PRESSED)
		return ;

	for (i = 0; i < 20; i++)
	{
		HAL_Delay(50);
		if (encode_button() == NO_BUTTON_PRESSED)  //松开按键
			return ;
	}

	*button_state = 0x20 | encode_button();  //按住按键
}

//按键编号
inline uint8_t encode_button(void)
{
	return !(uint8_t)HAL_GPIO_ReadPin(L_GPIO_Port, L_Pin) << 4 | !(uint8_t)HAL_GPIO_ReadPin(R_GPIO_Port, R_Pin) << 3 | !(uint8_t)HAL_GPIO_ReadPin(U_GPIO_Port, U_Pin) << 2 | !(uint8_t)HAL_GPIO_ReadPin(D_GPIO_Port, D_Pin) << 1 | !(uint8_t)HAL_GPIO_ReadPin(OK_GPIO_Port, OK_Pin);
}
