#include "spectrum.h"

#include "main.h"

#include "Adafruit_ZeroFFT.h"
#include "wave.h"

//产生频谱
void generate_spectrum(uint16_t *FFTValue, uint8_t *y)
{
	uint8_t max_index = spectrum_max(FFTValue, 0);
	uint8_t i;

	for (i = 0; i < FFT_POINT / 2; i++)
	{
		y[i] = GRAPH_HEIGHT * (FFTValue[max_index] - FFTValue[i]) / FFTValue[max_index];
	}
}

//找到频谱最大值
uint8_t spectrum_max(uint16_t *FFTValue, uint8_t ignore_dc)
{
	uint8_t i;
	uint8_t temp_max_index = ignore_dc ? 2 : 0;

	for (i = ignore_dc ? 3 : 1; i <= FFT_POINT / 2; i++)
		if (FFTValue[i] > FFTValue[temp_max_index])
			temp_max_index = i;

	return temp_max_index;
}

//计算频率
uint32_t get_frequency(uint16_t *FFTValue, uint32_t sample_rate)
{
	return FFT_BIN(spectrum_max(FFTValue, 1), sample_rate, FFT_POINT);
}
