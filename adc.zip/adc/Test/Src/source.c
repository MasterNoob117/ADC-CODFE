#include "source.h"
#include "main.h"
#include "tim.h"
#include "bit_operation.h"

#define SIGNAL_LENGTH 500

Signal_out signal = {.form = sqr_wave, .frequency = 1000, .amplitude = 165};

static const uint8_t sine_wave_value[SIGNAL_LENGTH] = {
		50, 50, 51, 51, 52, 53, 53, 54, 55, 55, 56, 56, 57, 58, 58, 59, 59, 60, 61, 61,
		62, 63, 63, 64, 64, 65, 66, 66, 67, 67, 68, 68, 69, 70, 70, 71, 71, 72, 72, 73,
		74, 74, 75, 75, 76, 76, 77, 77, 78, 78, 79, 79, 80, 80, 81, 81, 82, 82, 83, 83,
		84, 84, 85, 85, 86, 86, 86, 87, 87, 88, 88, 88, 89, 89, 90, 90, 90, 91, 91, 91,
		92, 92, 92, 93, 93, 93, 94, 94, 94, 94, 95, 95, 95, 96, 96, 96, 96, 96, 97, 97,
		97, 97, 97, 98, 98, 98, 98, 98, 98, 98, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99,
		99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99,
		99, 98, 98, 98, 98, 98, 98, 98, 97, 97, 97, 97, 97, 96, 96, 96, 96, 96, 95, 95,
		95, 94, 94, 94, 94, 93, 93, 93, 92, 92, 92, 91, 91, 91, 90, 90, 90, 89, 89, 88,
		88, 88, 87, 87, 86, 86, 86, 85, 85, 84, 84, 83, 83, 82, 82, 81, 81, 80, 80, 79,
		79, 78, 78, 77, 77, 76, 76, 75, 75, 74, 74, 73, 72, 72, 71, 71, 70, 70, 69, 68,
		68, 67, 67, 66, 66, 65, 64, 64, 63, 63, 62, 61, 61, 60, 59, 59, 58, 58, 57, 56,
		56, 55, 55, 54, 53, 53, 52, 51, 51, 50, 50, 49, 48, 48, 47, 46, 46, 45, 44, 44,
		43, 43, 42, 41, 41, 40, 40, 39, 38, 38, 37, 36, 36, 35, 35, 34, 33, 33, 32, 32,
		31, 31, 30, 29, 29, 28, 28, 27, 27, 26, 25, 25, 24, 24, 23, 23, 22, 22, 21, 21,
		20, 20, 19, 19, 18, 18, 17, 17, 16, 16, 15, 15, 14, 14, 13, 13, 13, 12, 12, 11,
		11, 11, 10, 10,  9,  9,  9,  8,  8,  8,  7,  7,  7,  6,  6,  6,  5,  5,  5,  5,
		 4,  4,  4,  3,  3,  3,  3,  3,  2,  2,  2,  2,  2,  1,  1,  1,  1,  1,  1,  1,
		 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
		 0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1,  1,  1,  1,  1,  1,  1,  2,  2,
		 2,  2,  2,  3,  3,  3,  3,  3,  4,  4,  4,  5,  5,  5,  5,  6,  6,  6,  7,  7,
		 7,  8,  8,  8,  9,  9,  9, 10, 10, 11, 11, 11, 12, 12, 13, 13, 13, 14, 14, 15,
		15, 16, 16, 17, 17, 18, 18, 19, 19, 20, 20, 21, 21, 22, 22, 23, 23, 24, 24, 25,
		25, 26, 27, 27, 28, 28, 29, 29, 30, 31, 31, 32, 32, 33, 33, 34, 35, 35, 36, 36,
		37, 38, 38, 39, 40, 40, 41, 41, 42, 43, 43, 44, 44, 45, 46, 46, 47, 48, 48, 49,
};

static const uint8_t triangle_wave_value[SIGNAL_LENGTH] = {
		 0,  0,  0,  1,  1,  2,  2,  2,  3,  3,  4,  4,  4,  5,  5,  6,  6,  6,  7,  7,
		 8,  8,  8,  9,  9, 10, 10, 10, 11, 11, 12, 12, 12, 13, 13, 14, 14, 14, 15, 15,
		16, 16, 16, 17, 17, 18, 18, 18, 19, 19, 20, 20, 20, 21, 21, 22, 22, 22, 23, 23,
		24, 24, 24, 25, 25, 26, 26, 26, 27, 27, 28, 28, 28, 29, 29, 30, 30, 30, 31, 31,
		32, 32, 32, 33, 33, 34, 34, 34, 35, 35, 36, 36, 36, 37, 37, 38, 38, 38, 39, 39,
		40, 40, 40, 41, 41, 42, 42, 42, 43, 43, 44, 44, 44, 45, 45, 46, 46, 46, 47, 47,
		48, 48, 48, 49, 49, 50, 50, 50, 51, 51, 52, 52, 52, 53, 53, 54, 54, 54, 55, 55,
		56, 56, 56, 57, 57, 58, 58, 58, 59, 59, 60, 60, 60, 61, 61, 62, 62, 62, 63, 63,
		64, 64, 64, 65, 65, 66, 66, 66, 67, 67, 68, 68, 68, 69, 69, 70, 70, 70, 71, 71,
		72, 72, 72, 73, 73, 74, 74, 74, 75, 75, 76, 76, 76, 77, 77, 78, 78, 78, 79, 79,
		80, 80, 80, 81, 81, 82, 82, 82, 83, 83, 84, 84, 84, 85, 85, 86, 86, 86, 87, 87,
		88, 88, 88, 89, 89, 90, 90, 90, 91, 91, 92, 92, 92, 93, 93, 94, 94, 94, 95, 95,
		96, 96, 96, 97, 97, 98, 98, 98, 99, 99, 99, 99, 99, 98, 98, 98, 97, 97, 96, 96,
		96, 95, 95, 94, 94, 94, 93, 93, 92, 92, 92, 91, 91, 90, 90, 90, 89, 89, 88, 88,
		88, 87, 87, 86, 86, 86, 85, 85, 84, 84, 84, 83, 83, 82, 82, 82, 81, 81, 80, 80,
		80, 79, 79, 78, 78, 78, 77, 77, 76, 76, 76, 75, 75, 74, 74, 74, 73, 73, 72, 72,
		72, 71, 71, 70, 70, 70, 69, 69, 68, 68, 68, 67, 67, 66, 66, 66, 65, 65, 64, 64,
		64, 63, 63, 62, 62, 62, 61, 61, 60, 60, 60, 59, 59, 58, 58, 58, 57, 57, 56, 56,
		56, 55, 55, 54, 54, 54, 53, 53, 52, 52, 52, 51, 51, 50, 50, 50, 49, 49, 48, 48,
		48, 47, 47, 46, 46, 46, 45, 45, 44, 44, 44, 43, 43, 42, 42, 42, 41, 41, 40, 40,
		40, 39, 39, 38, 38, 38, 37, 37, 36, 36, 36, 35, 35, 34, 34, 34, 33, 33, 32, 32,
		32, 31, 31, 30, 30, 30, 29, 29, 28, 28, 28, 27, 27, 26, 26, 26, 25, 25, 24, 24,
		24, 23, 23, 22, 22, 22, 21, 21, 20, 20, 20, 19, 19, 18, 18, 18, 17, 17, 16, 16,
		16, 15, 15, 14, 14, 14, 13, 13, 12, 12, 12, 11, 11, 10, 10, 10,  9,  9,  8,  8,
		 8,  7,  7,  6,  6,  6,  5,  5,  4,  4,  4,  3,  3,  2,  2,  2,  1,  1,  0,  0,
};

static uint16_t output_wave_value[SIGNAL_LENGTH];

static void set_output_parameters(void);

//AUX输出
void start_output(void)
{
	HAL_TIM_PWM_Start_DMA(&htim2, TIM_CHANNEL_2, (uint32_t *)output_wave_value, SIGNAL_LENGTH);
}

//AUX停止输出
void stop_output(void)
{
	HAL_TIM_PWM_Stop_DMA(&htim2, TIM_CHANNEL_2);
}

//设置输出范围
static void set_output_parameters(void)
{
	uint16_t i;
	uint16_t tim_period;

	tim_period = 64000000 / SIGNAL_LENGTH / signal.frequency;

	if (is_output_on())
		stop_output();

	TIM2->CNT = 0;
	__HAL_TIM_SET_AUTORELOAD(&htim2, tim_period - 1);

	switch (signal.form)
	{
	case sqr_wave:
		for (i = 0; i < SIGNAL_LENGTH; i++)
			output_wave_value[i] = (uint16_t)((50 + 50*signal.amplitude/165 * (i<SIGNAL_LENGTH/2?1:-1)) * (tim_period-1) / 100);
		break;

	case sin_wave:
		for (i = 0; i < SIGNAL_LENGTH; i++)
			output_wave_value[i] = (uint16_t)((sine_wave_value[i]-50) * (tim_period-1) / 100 * signal.amplitude / 165 + tim_period/2);
		break;

	case tri_wave:
		for (i = 0; i < SIGNAL_LENGTH; i++)
			output_wave_value[i] = (uint16_t)((triangle_wave_value[i]-50) * tim_period / 100 * signal.amplitude / 165 + tim_period/2);
		break;

	default:
		break;
	}

	if (is_output_on())
		start_output();
}

//提高100Hz输出频率
void increase_output_freq(void)
{
	if (signal.frequency < 2000)
	{
		signal.frequency += 100;
		set_output_parameters();
	}
}

//降低100Hz输出频率
void decrease_output_freq(void)
{
	if (signal.frequency > 100)
	{
		signal.frequency -= 100;
		set_output_parameters();
	}
}

//提高输出幅值0.05V
void increase_output_amplitude(void)
{
	if (signal.amplitude < 165)
	{
		signal.amplitude += 5;
		set_output_parameters();
	}
}

//降低输出幅值0.05V
void decrease_output_amplitude(void)
{
	if (signal.amplitude > 0)
	{
		signal.amplitude -= 5;
		set_output_parameters();
	}
}

//改变输出波形
void change_output_waveform(void)
{
	switch(signal.form)
	{
	case sqr_wave: signal.form = sin_wave; break;
	case sin_wave: signal.form = tri_wave; break;
	case tri_wave: signal.form = sqr_wave; break;
	default: break;
	}
	set_output_parameters();
}

//得到输出信息
Signal_out get_output_information(void)
{
	return signal;
}

//设置输出初始值
void output_init(void)
{
	set_output_parameters();
}
