#include "main.h"
#include "bit_operation.h"

#define BIT0 0x01
#define BIT1 0x02
#define BIT2 0x04
#define BIT3 0x08
#define BIT4 0x10
#define BIT5 0x20
#define BIT6 0x40
#define BIT7 0x80

static uint8_t mode_flag;

static uint8_t display_flag;

static uint8_t trigger_flag;


uint8_t is_displaying_wave(void)
{
	return ~display_flag & BIT0;
}

uint8_t is_displaying_spectrum(void)
{
	return display_flag & BIT0;
}

uint8_t is_displaying_scope_menu(void)
{
	return display_flag & BIT1;
}

uint8_t is_displaying_output_menu(void)
{
	return display_flag & BIT2;
}

uint8_t is_displaying_trigger_menu(void)
{
	return display_flag & BIT3;
}

uint8_t is_displaying_time_div(void)
{
	return (~display_flag & BIT4) && (~display_flag & BIT5);
}

uint8_t is_displaying_Vpp(void)
{
	return (~display_flag & BIT4) && (display_flag & BIT5);
}

uint8_t is_displaying_Vdc(void)
{
	return (display_flag & BIT4) && (~display_flag & BIT5);
}

uint8_t is_displaying_freq(void)
{
	return (display_flag & BIT4) && (display_flag & BIT5);
}

uint8_t need_fft(void)
{
	return (display_flag & BIT0) || ((display_flag & BIT5) && (display_flag & BIT4));
}

// 选择输出方式
void switch_wave_spectrum(void)
{
	display_flag ^= BIT0;
}

void toggle_scope_menu(void)
{
	display_flag ^= BIT1;
}

void toggle_output_menu(void)
{
	display_flag ^= BIT2;
}

void toggle_trigger_menu(void)
{
	display_flag ^= BIT3;
}

void next_information(void)
{
	display_flag ^= ((display_flag & BIT4) << 1) | BIT4;
}

uint8_t is_mic_input(void)
{
	return ~mode_flag & BIT0;
}

uint8_t is_output_on(void)
{
	return mode_flag & BIT1;
}

uint8_t is_auto_scale(void)
{
	return (~display_flag & BIT0) && (~mode_flag & BIT2);
}

uint8_t is_manual_scale(void)
{
	return (~display_flag & BIT0) && (mode_flag & BIT2);
}

uint8_t is_adjust_y_axis_scale(void)
{
	return  (~display_flag & BIT0) && (mode_flag & BIT2) && (~mode_flag & BIT3);
}

uint8_t is_adjust_y_axis_offset(void)
{
	return (~display_flag & BIT0) && (mode_flag & BIT2) && (mode_flag & BIT3);
}

uint8_t is_paused(void)
{
	return mode_flag & BIT4;
}

uint8_t is_sample_finished(void)
{
	return mode_flag & BIT5;
}

// 选择输入方式
void switch_channel(void)
{
	mode_flag ^= BIT0;
}

void toggle_output(void)
{
	mode_flag ^= BIT1;
}

void toggle_scale(void)
{
	mode_flag ^= BIT2;
}

void toggle_scale_offset(void)
{
	mode_flag ^= BIT3;
}

void toggle_pause(void)
{
	mode_flag ^= BIT4;
}

void pause(void)
{
	mode_flag |= BIT4;
}

void finish_sample(void)
{
	mode_flag |= BIT5;
}

void clear_finish_flag(void)
{
	mode_flag &= ~BIT5;
}

uint8_t is_trigger_on(void)
{
	return ~trigger_flag & BIT0;
}

uint8_t is_trigger_auto(void)
{
	return ~trigger_flag & BIT1;
}

uint8_t is_trigger_single(void)
{
	return trigger_flag & BIT1;
}

uint8_t get_trigger_edge(void)
{
	return trigger_flag & BIT2;
}

uint8_t is_trigger_fail(void)
{
	return ~trigger_flag & BIT3;
}

void toggle_trigger(void)
{
	trigger_flag ^= BIT0;
}

void switch_trigger_mode(void)
{
	trigger_flag ^= BIT1;
}

void switch_trigger_edge(void)
{
	trigger_flag ^= BIT2;
}

void trigger_fail(void)
{
	trigger_flag &= ~BIT3;
}

void trigger_success(void)
{
	trigger_flag |= BIT3;
}
