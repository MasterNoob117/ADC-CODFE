#include "stdio.h"
#include "main.h"

#include "bit_operation.h"
#include "oled.h"
#include "source.h"
#include "wave.h"

//坐标轴
void display_coordinate(void)
{
	OLED_DrawLine(GRAPH_START_X - 1, GRAPH_START_Y - 1, GRAPH_START_X + GRAPH_WIDTH, GRAPH_START_Y - 1, 1);
	OLED_DrawLine(GRAPH_START_X + GRAPH_WIDTH, GRAPH_START_Y + GRAPH_HEIGHT, GRAPH_START_X - 1, GRAPH_START_Y + GRAPH_HEIGHT, 1);
	OLED_DrawLine(GRAPH_START_X - 1, GRAPH_START_Y + GRAPH_HEIGHT, GRAPH_START_X - 1, GRAPH_START_Y - 1, 1);
	OLED_DrawLine(GRAPH_START_X + GRAPH_WIDTH, GRAPH_START_Y - 1, GRAPH_START_X + GRAPH_WIDTH, GRAPH_START_Y + GRAPH_HEIGHT, 1);

	OLED_DrawPoint(GRAPH_START_X + GRAPH_WIDTH + 1, GRAPH_START_Y, 1);
	OLED_DrawPoint(GRAPH_START_X + GRAPH_WIDTH + 2, GRAPH_START_Y, 1);
	OLED_DrawPoint(GRAPH_START_X + GRAPH_WIDTH + 1, GRAPH_START_Y + SCALE * 5, 1);
	OLED_DrawPoint(GRAPH_START_X + GRAPH_WIDTH + 2, GRAPH_START_Y + SCALE * 5, 1);
	OLED_DrawPoint(GRAPH_START_X + GRAPH_WIDTH + 1, GRAPH_START_Y + SCALE * 10, 1);
	OLED_DrawPoint(GRAPH_START_X + GRAPH_WIDTH + 2, GRAPH_START_Y + SCALE * 10, 1);
}

//y轴坐标
void display_y_axis(void)
{
	char str[5];

	sprintf(str, "%.1f", volt_on_y_axis.max_voltage);
	OLED_ShowString(GRAPH_START_X + GRAPH_WIDTH + 3, GRAPH_START_Y - 4, str, 8, 1);
	sprintf(str, "%.1f", volt_on_y_axis.center_voltage);
	OLED_ShowString(GRAPH_START_X + GRAPH_WIDTH + 3, GRAPH_START_Y + SCALE * 5 - 4, str, 8, 1);
	sprintf(str, "%.1f", volt_on_y_axis.min_voltage);
	OLED_ShowString(GRAPH_START_X + GRAPH_WIDTH + 3, GRAPH_START_Y + SCALE * 10 - 4, str, 8, 1);
}

//输出波形
void display_wave(const uint8_t *y)
{
	uint8_t x;
	for (x = GRAPH_START_X; x < GRAPH_WIDTH - 1; x++)
		OLED_DrawLine(x, y[x-GRAPH_START_X], x + 1, y[x-GRAPH_START_X+1], 1);
	OLED_DrawPoint(x, y[x-GRAPH_START_X], 1);
}

//时间分度
void display_time_div(uint32_t sample_rate)
{
	char str[10];

	if (sample_rate <= 5000)
		sprintf(str, "%ums", (uint16_t)(5000 / sample_rate));
	else if (sample_rate <= 5000000)
		sprintf(str, "%uus", (uint16_t)(5000000 / sample_rate));
	OLED_ShowString(GRAPH_START_X+90, GRAPH_START_Y + GRAPH_HEIGHT + 1, str, 8, 1);
}

//中心电压
void display_Vdc(float Vdc)
{
	char str[8];
	sprintf(str, "%.2f", Vdc);
	OLED_ShowString(GRAPH_START_X, GRAPH_START_Y + GRAPH_HEIGHT + 1, str, 8, 1);
}

//峰峰值
void display_Vpp(float Vpp)
{
	char str[8];
	sprintf(str, "%.2f", Vpp);
	OLED_ShowString(GRAPH_START_X, GRAPH_START_Y + GRAPH_HEIGHT + 1, str, 8, 1);
}

//显示频率
void display_frequency(uint32_t freq)
{
	char str[9];

	if (freq < 1000)  //Hz
		sprintf(str, "%luHz", freq);
	else if (freq < 1000000)  //kHz
		sprintf(str, "%.1fkHz", freq / 1000.0);
	OLED_ShowString(GRAPH_START_X, GRAPH_START_Y + GRAPH_HEIGHT + 1, str, 8, 1);
}

//显示状态
void display_status(void)
{
	if (is_auto_scale())
		OLED_ShowString(GRAPH_START_X + 45, GRAPH_START_Y + GRAPH_HEIGHT + 1, "AUTO", 8, 1);
	else if (is_adjust_y_axis_offset())
		OLED_ShowString(GRAPH_START_X + 45, GRAPH_START_Y + GRAPH_HEIGHT + 1, "MO", 8, 1);
}

//显示麦克风与AIN引脚
void display_channel(void)
{
	if (is_mic_input())  // Channel: microphone
		OLED_ShowString(GRAPH_START_X , GRAPH_START_Y + GRAPH_HEIGHT + 1, "MIC", 8, 1);
	else  // Channel: Ain
		OLED_ShowString(GRAPH_START_X , GRAPH_START_Y + GRAPH_HEIGHT + 1, "IN", 8, 1);
}

//切换频率、时间/麦克风、AIN引脚
void display_scope_menu(void)
{
	if (is_displaying_time_div())  // 时间
		OLED_ShowString(GRAPH_START_X, GRAPH_START_Y, "U-T", 8, 1);
	else if (is_displaying_freq()) // 频率
		OLED_ShowString(GRAPH_START_X, GRAPH_START_Y, "U-F", 8, 1);

	if (is_mic_input())  //麦克风
		OLED_ShowString(GRAPH_START_X, GRAPH_START_Y + 8, "D-MIC", 8, 1);
	else  //AIN
		OLED_ShowString(GRAPH_START_X, GRAPH_START_Y + 8, "D-Ain", 8, 1);
}

//显示频谱
void display_spectrum(uint8_t *y)
{
	uint8_t x;
	for (x = 0; x < 128; x++)
		OLED_DrawLine(x, y[x], x, GRAPH_HEIGHT + 1, 1);
}

//显示采样率
void display_freq_div(uint32_t sample_rate)
{
	char str[14];
	sprintf(str, "%.2f", sample_rate / 16000.0);
	OLED_ShowString(1, 56, str, 8, 1);
}

//信号发生器菜单
void display_output_menu(Signal_out signal)
{
	OLED_ShowString(GRAPH_START_X, 8, "L-F+", 8, 1);
	OLED_ShowString(GRAPH_START_X, 16, "R-F-", 8, 1);
	OLED_ShowString(GRAPH_START_X, 24, "U-A+", 8, 1);
	OLED_ShowString(GRAPH_START_X, 32, "D-A-", 8, 1);

	switch(signal.form)
	{
	case sqr_wave:
		OLED_ShowString(GRAPH_START_X, 40, "OK-squ", 8, 1);
		break;
	case sin_wave:
		OLED_ShowString(GRAPH_START_X, 40, "OK-sin", 8, 1);
		break;
	case tri_wave:
		OLED_ShowString(GRAPH_START_X, 40, "OK-tri", 8, 1);
		break;
	default:
		break;
	}
}

//触发器菜单
void display_trigger_menu(void)
{
	OLED_ShowString(GRAPH_START_X, GRAPH_START_Y, "TRIGGER MENU", 8, 1);
	if (is_trigger_on())
		OLED_ShowString(GRAPH_START_X, GRAPH_START_Y + 8, "1-trigger ON", 8, 1);
	else
		OLED_ShowString(GRAPH_START_X, GRAPH_START_Y + 8, "1-trigger OFF", 8, 1);

	if (is_trigger_auto())
		OLED_ShowString(GRAPH_START_X, GRAPH_START_Y + 16, "2-auto", 8, 1);
	else if (is_trigger_single())
		OLED_ShowString(GRAPH_START_X, GRAPH_START_Y + 16, "2-single", 8, 1);

	if (get_trigger_edge())
		OLED_ShowString(GRAPH_START_X, GRAPH_START_Y + 24, "3-falling", 8, 1);
	else
		OLED_ShowString(GRAPH_START_X, GRAPH_START_Y + 24, "3-rising", 8, 1);
}


void display_trigger_edge(void)
{
	if (get_trigger_edge())
		OLED_ShowChar(GRAPH_START_X + 55, GRAPH_START_Y + GRAPH_HEIGHT + 1, 125, 8, !is_trigger_fail());  // falling edge
	else
		OLED_ShowChar(GRAPH_START_X + 55, GRAPH_START_Y + GRAPH_HEIGHT + 1, 124, 8, !is_trigger_fail());  // rising edge
}
