#ifndef __BUTTON_H_
#define __BUTTON_H_

#include "stm32g0xx_hal.h"

// Button states
#define NO_BUTTON_PRESSED 0x00
#define L_BUTTON_PRESSED 0x10
#define R_BUTTON_PRESSED 0x08
#define U_BUTTON_PRESSED 0x04
#define D_BUTTON_PRESSED 0x02
#define OK_BUTTON_PRESSED 0x01
#define LR_BUTTON_HOLD 0x38
#define UD_BUTTON_HOLD 0x26
#define L_BUTTON_HOLD 0x30
#define R_BUTTON_HOLD 0x28
#define U_BUTTON_HOLD 0x24
#define D_BUTTON_HOLD 0x22
#define OK_BUTTON_HOLD 0x21

void read_button(uint8_t *button_state);
uint8_t encode_button(void);

#endif
