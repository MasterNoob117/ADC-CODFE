#ifndef __BIT_OPERATION_H_
#define __BIT_OPERATION_H_

#include "stm32g0xx_hal.h"

uint8_t is_displaying_wave(void);
uint8_t is_displaying_spectrum(void);
uint8_t is_displaying_scope_menu(void);
uint8_t is_displaying_output_menu(void);
uint8_t is_displaying_trigger_menu(void);
uint8_t is_displaying_time_div(void);
uint8_t is_displaying_Vpp(void);
uint8_t is_displaying_Vdc(void);
uint8_t is_displaying_freq(void);
uint8_t need_fft(void);
void switch_wave_spectrum(void);
void toggle_scope_menu(void);
void toggle_output_menu(void);
void toggle_trigger_menu(void);
void next_information(void);
void output_init(void);

uint8_t is_mic_input(void);
uint8_t is_output_on(void);
uint8_t is_auto_scale(void);
uint8_t is_manual_scale(void);
uint8_t is_adjust_y_axis_scale(void);
uint8_t is_adjust_y_axis_offset(void);
uint8_t is_paused(void);
uint8_t is_sample_finished(void);
void switch_channel(void);
void toggle_output(void);
void toggle_scale(void);
void toggle_scale_offset(void);
void toggle_pause(void);
void pause(void);
void finish_sample(void);
void clear_finish_flag(void);

uint8_t is_trigger_on(void);
uint8_t is_trigger_auto(void);
uint8_t is_trigger_single(void);
uint8_t get_trigger_edge(void);
uint8_t is_trigger_fail(void);
void toggle_trigger(void);
void switch_trigger_mode(void);
void switch_trigger_edge(void);
void trigger_fail(void);
void trigger_success(void);

#endif
