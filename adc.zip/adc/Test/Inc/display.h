#ifndef __DISPLAY_H_
#define __DISPLAY_H_

#include "stm32g0xx_hal.h"

#include "source.h"

void display_coordinate(void);
void display_y_axis(void);
void display_wave(const uint8_t *wave);
void display_time_div(uint32_t sample_rate);
void display_Vdc(float Vdc);
void display_Vpp(float Vpp);
void display_frequency(uint32_t freq);
void display_status(void);
void display_channel(void);
void display_scope_menu(void);
void display_spectrum(uint8_t *y);
void display_freq_div(uint32_t sample_rate);
void display_output_menu(Signal_out signal);
void display_trigger_menu(void);
void display_trigger_edge(void);

#endif
