#ifndef __SPECTRUM_H_
#define __SPECTRUM_H_

#include "stm32g0xx_hal.h"

void generate_spectrum(uint16_t *FFTValue, uint8_t *y);
uint8_t spectrum_max(uint16_t *FFTValue, uint8_t ignore_dc);
uint32_t get_frequency(uint16_t *FFTValue, uint32_t sample_rate);

#endif
