#ifndef __SOURCE_H_
#define __SOURCE_H_

#include "stm32g0xx_hal.h"

typedef enum
{
	sqr_wave = 1,
	sin_wave = 2,
	tri_wave = 3
} waveform;

typedef struct
{
	waveform form;
	uint16_t frequency;
	uint8_t amplitude;
} Signal_out;

void start_output(void);
void stop_output(void);
void increase_output_freq(void);
void decrease_output_freq(void);
void increase_output_amplitude(void);
void decrease_output_amplitude(void);
void change_output_waveform(void);
Signal_out get_output_information(void);

#endif
