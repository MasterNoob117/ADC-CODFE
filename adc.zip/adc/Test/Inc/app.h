#ifndef __APP_H_
#define __APP_H_

#include "stm32g0xx_hal.h"

void button_operations(uint8_t button_state);
void get_wave(uint16_t *ADCValue, uint8_t *wave);
void wave_view(uint16_t *ADCValue, uint16_t *FFTValue, uint32_t sample_rate, uint8_t *wave);
void get_spectrum(uint16_t *FFTValue, uint8_t *spectrum);
void spectrum_view(uint8_t *spectrum, uint32_t sample_rate);
void copy_array(uint16_t *array1, uint16_t *array2, uint16_t length);

#endif
