#ifndef __SAMPLE_H_
#define __SAMPLE_H_

#include "stm32g0xx_hal.h"

#define SAMPLE_POINTS 256

uint32_t get_sample_rate(void);
void inc_sample_rate(void);
void dec_sample_rate(void);
void set_sample_rate(uint32_t sample_rate);
void start_sample(uint16_t *ADCValue);
void change_ADC_channel(void);

#endif
