#ifndef __WAVE_H_
#define __WAVE_H_

#include "stm32g0xx_hal.h"

#define GRAPH_START_X 1
#define GRAPH_START_Y 4
#define GRAPH_WIDTH 101
#define GRAPH_HEIGHT 51

#define SCALE 5

typedef struct
{
	float center_voltage;
	float max_voltage;
	float min_voltage;
} Y_Axis;

float get_pp_voltage(uint16_t *ADCValue);
float get_dc_voltage(uint16_t *ADCValue);
void auto_scale(uint16_t *ADCValue);
void manual_inc_scale(void);
void manual_dec_scale(void);
void manual_inc_offset(void);
void manual_dec_offset(void);
void generate_wave(uint16_t *ADCValue, uint8_t *y);
uint16_t trigger(uint16_t *ADCValue, uint16_t total_points);

extern Y_Axis volt_on_y_axis;

#endif
